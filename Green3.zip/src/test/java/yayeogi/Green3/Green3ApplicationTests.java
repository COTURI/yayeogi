package yayeogi.Green3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Green3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
